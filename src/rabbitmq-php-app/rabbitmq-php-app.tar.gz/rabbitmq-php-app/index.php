<?php
require('vendor/autoload.php');
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

$i = 0;
//Getting VCAP info
$service_blob = json_decode($_ENV['VCAP_SERVICES'], true);
$rabbitmq_services = array();
foreach($service_blob as $service_provider => $service_list) {
    // looks for rabbitmq service, can be declared in manifest.yml
    if ($service_provider === $_ENV['RMQ_SERVICE'] || $service_provider === 'p-rabbitmq-35') {
        foreach($service_list as $rabbitmq_service) {
            $rabbitmq_services[] = $rabbitmq_service;
        }
        continue;
    }

}

for ($i = 1; $i <= count($rabbitmq_services); $i++) {
    //getting all the creds
    $amqp = $rabbitmq_services[$i-1]['credentials']['protocols']['amqp'];
    $hostname = $amqp['host'];
    $port = $amqp['port'];
    $user = $amqp['username'];
    $password = $amqp['password'];
    $vhost = $amqp['vhost'];


    for($j = 1; $j <= 1000; $j++){
      //sending OK
      $connection = new AMQPStreamConnection($hostname, $port, $user, $password, $vhost);
      $channel = $connection->channel();
      $channel->queue_declare('hello' . $j , false, false, false, false);
      for($k = 1; $k <= 4320; $k++){
        $msg = new AMQPMessage('OK' . $k * $k * $k * $k);
        $channel->basic_publish($msg, '', 'hello' . $j);
      }
      //echo '<h1>[x] Sent OK!\h1>';
      $channel->close();
      $connection->close();
      sleep(1);
    }

}

?>
</body>
</html>
